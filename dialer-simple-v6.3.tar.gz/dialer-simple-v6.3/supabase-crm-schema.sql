-- ════════════════════════════════════════════════════════════════
-- CRM additions to the Call Booklet schema
-- Paste this whole file into Supabase → SQL Editor → Run.
-- Safe to re-run.
-- ════════════════════════════════════════════════════════════════

-- ── Profiles (team members) ──────────────────────────────────
create table if not exists public.profiles (
  id          serial primary key,
  name        text not null unique,
  created_at  timestamptz not null default now()
);

-- ── Deals ────────────────────────────────────────────────────
create table if not exists public.deals (
  id              serial primary key,
  property_id     text references public.properties(id) on delete set null,

  -- Snapshot of property info at time of deal creation (so deals survive list replacement)
  owners          text not null default '',
  property_address text not null default '',
  mailing_address text not null default '',
  bed             integer,
  bath            numeric(3,1),
  sqft            integer,
  year_built      integer,
  source_list     text default '',

  -- Stage: hot, underwriting, offer, contract, closed
  stage           text not null default 'hot',
  deal_type       text not null default 'assignment',  -- 'assignment' or 'flip'

  -- Financials (all optional)
  arv             numeric(12,2),
  repairs         numeric(12,2),
  seller_asking   numeric(12,2),
  your_offer      numeric(12,2),
  mao_percent     numeric(5,2) default 70,  -- editable 70% rule

  -- Assignment-specific
  assignment_fee  numeric(12,2),
  buyer_closing_costs numeric(12,2),

  -- Flip-specific
  purchase_closing_costs numeric(12,2),
  holding_monthly numeric(12,2),
  holding_months  numeric(5,2),
  selling_costs_pct numeric(5,2),  -- as percent of resale
  resale_price    numeric(12,2),

  -- Assignment
  assigned_to_profile integer references public.profiles(id) on delete set null,
  created_by_profile  integer references public.profiles(id) on delete set null,

  -- Lifecycle
  closed_at       timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  archived        boolean not null default false
);
create index if not exists deals_stage_idx       on public.deals(stage);
create index if not exists deals_assigned_idx    on public.deals(assigned_to_profile);
create index if not exists deals_property_idx    on public.deals(property_id);
create index if not exists deals_updated_idx     on public.deals(updated_at desc);

-- ── Comps (link cards on a deal) ─────────────────────────────
create table if not exists public.deal_comps (
  id          serial primary key,
  deal_id     integer not null references public.deals(id) on delete cascade,
  label       text not null default '',
  url         text not null default '',
  sale_price  numeric(12,2),
  created_at  timestamptz not null default now()
);
create index if not exists deal_comps_deal_idx on public.deal_comps(deal_id);

-- ── Documents (link cards on a deal) ─────────────────────────
create table if not exists public.deal_docs (
  id          serial primary key,
  deal_id     integer not null references public.deals(id) on delete cascade,
  label       text not null default '',
  url         text not null default '',
  doc_type    text not null default 'other',  -- contract, photos, comps, other
  created_at  timestamptz not null default now()
);
create index if not exists deal_docs_deal_idx on public.deal_docs(deal_id);

-- ── Notes / activity ─────────────────────────────────────────
create table if not exists public.deal_notes (
  id          serial primary key,
  deal_id     integer not null references public.deals(id) on delete cascade,
  profile_id  integer references public.profiles(id) on delete set null,
  body        text not null default '',
  kind        text not null default 'note',  -- note, stage_change, offer, system
  created_at  timestamptz not null default now()
);
create index if not exists deal_notes_deal_idx on public.deal_notes(deal_id, created_at);

-- ── Add profile_id to calls table for per-rep attribution ────
alter table public.calls
  add column if not exists profile_id integer references public.profiles(id) on delete set null;

-- ── Touch deals.updated_at trigger ───────────────────────────
create or replace function public.deals_touch() returns trigger as $$
begin new.updated_at = now(); return new; end;
$$ language plpgsql;

drop trigger if exists deals_touch on public.deals;
create trigger deals_touch before update on public.deals
  for each row execute procedure public.deals_touch();

-- ── RLS: lock these tables down too ─────────────────────────
alter table public.profiles   enable row level security;
alter table public.deals      enable row level security;
alter table public.deal_comps enable row level security;
alter table public.deal_docs  enable row level security;
alter table public.deal_notes enable row level security;
-- Service role bypasses RLS; no public policies needed.
