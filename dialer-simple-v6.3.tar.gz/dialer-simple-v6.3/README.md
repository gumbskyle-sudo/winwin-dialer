# Call Booklet — Simple Edition

Single-page web app. Three services. Five-person team. Shared password. Booklet dialer + CRM pipeline in one tool.

```
┌──────────────┐    ┌─────────────────┐    ┌──────────┐
│  index.html  │───▶│ Netlify Function│───▶│ Twilio   │
│  (browser)   │    │  (one file)     │    │          │
└──────────────┘    └────────┬────────┘    └──────────┘
                             │
                             ▼
                       ┌──────────┐
                       │ Supabase │  (properties, leads, calls, deals)
                       └──────────┘
```

No build step. No npm install. No framework. The HTML you see is the app you ship.

---

## What you get

- **Shared team password.** One password unlocks the app for everyone.
- **Profile picker per device.** Each teammate picks/creates their name on first load — sticks to that device. Calls, notes, and deal assignments get attributed to them.
- **Property cards** with click-to-call, status pips, mark-as-called, lead status, notes.
- **CSV upload** with auto column detection.
- **Buy phone numbers** from any US area code, set active caller ID, release when done.
- **Click-to-call** — Twilio rings your cell first, you answer, it dials the seller showing your local number.
- **Group call log + KPIs.** Total calls, contact rate, talk time, peak hour, hot/warm leads, top caller ID.
- **CRM Pipeline** (NEW). 5-stage kanban: Hot → Underwriting → Offer → Contract → Closed. When you tag a lead hot/warm in the dialer, a "→ Send to pipeline" button appears. One tap creates a deal card.
- **Deal detail view** (NEW). Property info, deal type toggle (Assignment vs Fix & Flip), full financials with auto-MAO and projected-profit, comp links, document links, activity feed (calls + notes interleaved). Auto-generated Zillow link on every deal.

---

## One-time setup (~15 min)

### 1. Supabase (database)

1. Sign up at <https://supabase.com> → **New project**. Free tier is fine.
2. Wait ~1 min for it to provision.
3. **SQL Editor** → paste the entire contents of `supabase-schema.sql` → **Run**.
4. **SQL Editor again** → paste the entire contents of `supabase-crm-schema.sql` → **Run**. (This adds the CRM tables.)
5. **Settings → API**. Copy two values:
   - `Project URL`
   - `service_role` key (under "Project API keys" — *not* the anon key. Treat like a master password.)

### 2. Twilio (calling)

1. Sign up at <https://www.twilio.com/try-twilio>. Trial gives ~$15 credit; you'll need to upgrade ($20 min) to call un-verified numbers.
2. Console home → copy your `Account SID` (starts with `AC…`).
3. Console → **Account** → **API keys & tokens** → **Create API key**. Type *Standard*, name it *Dialer*. Copy the SID (`SK…`) and the Secret. **The Secret is shown ONCE** — save it now.

### 3. Netlify (hosting + backend)

1. Drag the entire folder onto <https://app.netlify.com/drop>, or push to GitHub and connect.
2. Once deployed, go to **Site configuration → Environment variables → Add a variable**. Add all six:

| Key                          | Value                                                |
|------------------------------|------------------------------------------------------|
| `SUPABASE_URL`               | from step 1.4                                        |
| `SUPABASE_SERVICE_ROLE_KEY`  | from step 1.4                                        |
| `TWILIO_ACCOUNT_SID`         | from step 2.2                                        |
| `TWILIO_API_KEY_SID`         | from step 2.3                                        |
| `TWILIO_API_KEY_SECRET`      | from step 2.3                                        |
| `ACCESS_PASSWORD`            | invent a long random string for your team to share   |

3. **Deploys → Trigger deploy** so the function picks up the env vars.

Your app URL is `https://YOURSITE.netlify.app`. That's what your team uses.

---

## First time using it

1. Open the URL → enter the team password from `ACCESS_PASSWORD`.
2. **⚙ Settings** → enter your phone in E.164 (`+15085551234`) → Save.
3. **📞 Numbers** → Search & Buy → enter area code → Search → Buy one (~$1.15/mo).
4. The number auto-becomes Active. Confirm in the header strip.
5. **⬆ Upload List** → drop a CSV → review the column mapping → Import.
6. Tap any phone number on a card. Your phone rings. Answer. Twilio dials the seller. Talk.

Each teammate does steps 1, 2 once on their own device. Everyone shares the property list, lead state, owned numbers, and call log.

---

## CSV format

Auto-detection works for most skip-trace exports. The columns it looks for (case-insensitive):

| Mapping            | Headers it recognizes                                    |
|--------------------|----------------------------------------------------------|
| ID (optional)      | `ID`, `Property ID`, `Record ID`, `UID`                  |
| Owners             | `Owners`, `Owner`, `Owner Name`, `Full Name`, `Name`     |
| Property address   | `Property Address`, `Site Address`, `Address`, `Street`  |
| Mailing address    | `Mailing Address`, `Mail Address`, `Owner Address`       |
| Phones             | `Phone1`, `Phone2`, … `Mobile1`, `Cell1`, etc.           |
| Phone types        | `Phone1 Type`, `Phone2 Type`                             |

Whatever doesn't auto-detect, you map manually in the upload preview before importing. See `sample-list.csv` for an example. The format that works cleanly: one row per property, separate columns for each phone (numbered), optional Type column for each.

---

## Using the CRM

**Sending hot leads to the pipeline.** When you mark a lead hot or warm in the booklet, a yellow "→ Send to pipeline" button appears at the bottom of the card. Tap it once and the deal shows up in the Pipeline tab in the Hot Lead column. The button changes to "✓ In pipeline" so you don't double-send.

**Opening a deal.** Switch to the Pipeline tab (top of the page), tap any card. The deal detail view slides up with everything in one place.

**The five pipeline stages:**

- **Hot Lead** — seller said yes-ish, no offer yet
- **Underwriting** — running comps, estimating repairs
- **Offer Out** — number is on the table
- **Under Contract** — both parties signed
- **Closed** — money in the bank

Move a deal through stages by tapping the stage buttons at the top of the deal detail. Stage changes get logged in the activity feed.

**Auto-calculations.** Type in ARV and Repairs and the MAO (Maximum Allowable Offer) calculates live using the 70% rule. You can change the percentage per-deal. For Fix & Flip deals you also get a projected-profit calculation based on resale price, repairs, holding costs, and selling costs.

**Comps and documents.** Each deal has a "Comps" section (paste Zillow/Redfin sold-comp links) and a "Documents" section (paste DocuSign/Drive/Dropbox links). A Zillow page link for the property itself is auto-generated.

**Activity feed.** Calls placed on the property's phone numbers from the dialer automatically appear in the deal's activity, mixed with manually-added notes. So when someone asks "what's the status on Hale Rd," you open the deal and see the whole history in one place.

**Profiles.** First time each teammate opens the app on their device, they pick or create their profile (just first name). After that, their name attaches to every call and note. Switch profile anytime via the badge in the header.

---

## What's new in v5

Three additions:

### 1. Owner Last Name

Now a dedicated field on every property + deal. Auto-derived on CSV import by parsing the "Owners" string. Shown:
- On dialer cards as a blue badge next to the full names
- On pipeline kanban cards (instead of the full "DAVID & AMY JENKINS" — much easier to scan)
- As an editable field on the deal detail view

If your existing data doesn't have last names filled in yet, the schema migration auto-backfills them from the Owners string.

### 2. VA / Pre-existing Notes

Each property card in the dialer now has a collapsible **📋 VA / pre-existing notes** section. Paste in:
- Notes from your VA's calls
- Transcripts of prior recordings
- Anything the caller should see *before* picking up the phone

Auto-saves as you type (1.5 sec debounce). Different from "Call notes" — that's the live-conversation notes; VA notes are pre-call context.

### 3. Deal Qualifier Form

A structured 14-field form on every Deal Detail view, designed for after-call underwriting. Fields cover:
- **Motivation** (why selling) and **Timeline**
- **Condition** (5-level scale), **Repairs needed**
- **Asking price**, **Mortgage balance**, **Monthly payment**
- **Occupancy** (owner/tenant/vacant), **Listed with agent?**
- **Decision makers**, **Liens or back taxes**
- **Why us instead of retail**, **Competing offers**
- **Extra notes** catch-all

When you save the form, the deal gets a "Qualifier completed" timestamp + who completed it. Re-save anytime to update.

### Deploying v5 (~5 minutes)

1. **Run new SQL in Supabase.** SQL Editor → paste `supabase-v5-schema.sql` → Run. Backfills existing owners' last names automatically. Doesn't touch any other data.

2. **Drag the `dialer-simple-v5` folder onto your Netlify site** to redeploy.

3. **No new env vars needed.** Everything reuses what you have.

---

## What's new in v6

Two big additions: **Cash Buyers** and **VA Audio Recordings**.

### Cash Buyers

A new **💰 Buyers** tab in the main nav. Manage your cash buyers list:

- **Add buyers one at a time** with full criteria: name, company, email, phone, location, buy-box (free text), price range, property types, rehab tolerance, preferred areas, proof-of-funds flag, 0-5 star rating, notes, active/inactive toggle
- **Per-buyer "Send deal" button** opens an email composer pre-filled with deal details — sends to that one buyer
- **Multi-select with "📧 Blast selected" button** at the top — pick any number of buyers (or all active), one composer, sends to all
- **Personalization placeholders** (`{first_name}`, `{address}`) auto-fill per recipient
- **Auto-tracked stats:** every buyer's row shows how many deals you've sent them, when the last one went
- **Send history per deal** — the Deal Detail view's new "Cash Buyers" section shows "Sent to: Buyer X, Buyer Y" with timestamps, so you don't accidentally double-send

### VA Audio Recordings

Audio file uploads on every property — both on the dialer card AND on the deal detail view.

- **Upload via "🎙 Upload recording" button** under VA notes — accepts mp3, m4a, wav, webm, ogg, aac
- **25 MB max per file**
- **Plays inline** with a standard audio player. No download needed; signed URLs expire after 1 hour for security
- **Auto-deletes after 30 days** via a daily cron job (Netlify Scheduled Function at 3am UTC). Each recording shows "Xd left" before expiration.
- **Manual delete** with the ✕ button if you want to remove one early
- **Storage:** Supabase Storage (private bucket, signed URLs only — never publicly accessible)

### Deploying v6 (~10 minutes)

#### 1. New env vars (5 vars total this time)

In Netlify → Site configuration → Environment variables, add these:

| Key | Value | Purpose |
|---|---|---|
| `RESEND_API_KEY` | `re_xxx...` | from Resend dashboard |
| `RESEND_FROM_EMAIL` | `Tony Pyro <tony@yourdomain.com>` | the "from" address — must be a domain you've verified in Resend |
| `RESEND_REPLY_TO` | `tony@yourdomain.com` | (optional) where replies go if different from From |

The Twilio Auth Token from v4 still needed. All other env vars from prior versions stay the same.

#### 2. Sign up for Resend (for email)

1. Go to <https://resend.com> → sign up (free tier: 3,000 emails/month, 100/day)
2. **Verify a domain** — Resend requires you to own a domain to send from (e.g. `pyropharmz.com` or whatever you control). They'll give you 3 DNS records to add at your registrar (~5 min, propagates within an hour usually).
3. After domain verification → **API Keys** → Create API Key → copy the `re_...` value
4. Paste into Netlify env vars

**Honest note:** without a verified domain, you can only send from `onboarding@resend.dev` for testing. That goes to spam frequently — verify your domain before using this for real buyer blasts.

#### 3. Run the new SQL

Supabase → SQL Editor → paste `supabase-v6-schema.sql` → Run.

This creates:
- The `buyers`, `buyer_sends`, and `va_recordings` tables
- A private Storage bucket called `va-recordings` (25 MB upload cap, audio-only mime types)

#### 4. Drag the `dialer-simple-v6` folder onto your Netlify site

Same as before. The new `cleanup-recordings.js` scheduled function will auto-register from `netlify.toml` and start running daily at 3am UTC.

#### 5. (Optional) Test the scheduled cleanup manually

In your browser: `https://YOURSITE.netlify.app/api?action=cleanup-recordings`
(or the function will run automatically on its own schedule)

---

## Day-to-day notes

**Adding a teammate.** Send them the URL and the password. They open the page on their phone, enter the password, set their own forwarding number in Settings.

**Replacing the list.** Upload a new CSV with "Replace existing" checked. Wipes everything (properties, leads, notes). Use this when you've got a fresh skip-trace.

**Adding to the list.** Upload with "Replace existing" UNCHECKED. New rows merge in; existing rows update.

**Rotating caller IDs.** If pickup rates drop on a number, buy a new one and set it active. Release the old one to stop being billed.

**Sign out.** Settings → Sign out. Useful if you hand your phone to someone or are on shared hardware.

---

## SMS Drip Campaigns (NEW in v4)

The app can now send text messages — manual replies and automated drip sequences — to leads who have consented to texts.

### Setup (one-time, before turning SMS on)

1. **Run the new schema in Supabase.** SQL Editor → paste `supabase-sms-schema.sql` → Run.

2. **Add a Twilio env var on Netlify.** A new one is required for SMS webhook verification:
   - **Key:** `TWILIO_AUTH_TOKEN`
   - **Value:** your main Twilio Auth Token (find it on the Twilio Console dashboard — not the API Key Secret, but the *Auth Token* listed at the top of your account page)
   - Then **Trigger deploy → Clear cache and deploy site**.

3. **Configure Twilio webhooks.** In Twilio Console → Phone Numbers → pick the number you want to use for SMS → Messaging Configuration:
   - **A MESSAGE COMES IN:** `https://YOURSITE.netlify.app/api?action=twilio-inbound` (POST)
   - **STATUS CALLBACK URL:** `https://YOURSITE.netlify.app/api?action=twilio-status` (POST)
   - Save.

4. **A2P 10DLC registration** (mandatory before texts will reliably deliver):
   - Twilio Console → Messaging → Regulatory Compliance → A2P 10DLC
   - Register your **Brand** ($4 one-time, needs your business EIN, address, website)
   - Submit a **Campaign**: choose type **"Customer Care / Account Notification"** (NOT Marketing). Describe it as: *"Opt-in follow-up texts to motivated home sellers who provided verbal consent during a phone call."*
   - Provide sample messages (copy any of the drip templates from the app).
   - Wait 3-7 days for approval.

5. **In the dialer:** Settings → SMS section → pick your sending number from the dropdown and enter your first name (used in `{your_name}` template fills). Save.

### How to use it

**Get consent on every call.** Callers should ask at the end of every call:

> *"Quick question before we wrap — can I send you a follow-up text with my info? Reply STOP anytime to opt out."*

If the seller says yes, the caller opens the deal → toggles **SMS consent → Verbal** and selects the cell phone number from the dropdown. That logs the consent timestamp and the caller's name.

**Manual texts.** Open any deal that has SMS consent → scroll to Text Messages → type, send. Two-way conversation lives in the deal.

**Start a drip.** Same place — Drip Campaigns section. Pick one:
- **Reconsider** — 4 messages over 24 days, after you made an offer they declined
- **Working with Comp** — 1 message, fires immediately. Use it 3 days before their close date with another buyer.
- **3-Month Check-in** — 1 message, fires immediately. Use at the agreed 3-month mark.
- **6-Month Check-in** — 1 message, fires immediately. Use at the agreed 6-month mark.

You confirm once; the rest sends automatically on schedule. Messages only fire 8am-9pm Eastern time.

**When they reply.** Inbox tab in the top nav. Their reply auto-pauses any active drip and shows up in the Inbox. You reply manually from inside the deal.

**STOP keyword.** Any reply containing STOP / UNSUBSCRIBE / CANCEL / QUIT / END / OPTOUT automatically:
- Adds the number to a permanent opt-out list
- Pauses all active drips for that lead
- Sends an opt-out confirmation back to them
- Marks the lead's consent as `revoked`

### What can go wrong

- **Texts not delivering** — most likely A2P 10DLC not approved yet, or the wrong sending number is configured.
- **"No SMS consent on file"** — toggle Verbal/Written consent on the deal first.
- **Drips not firing** — they only run during 8am-9pm ET. The app pings the drip processor every 5 minutes while a teammate has the app open. For after-hours processing, set up a Netlify scheduled function (advanced).
- **Twilio account suspended** — you sent texts without A2P 10DLC registration, or carriers flagged your content as spam. Don't do this.

### Legal reality

This system is built to be compliant **if** you:
1. Only text people who gave verbal/written consent during a call
2. Have A2P 10DLC registered with Twilio
3. Honor STOP requests immediately (the app does this automatically)
4. Don't text outside 8am-9pm

The author isn't a lawyer. TCPA violations are $500-$1,500 per text. If you're scaling SMS, talk to a wholesaling attorney before you turn it on at volume.

---

## CRM tips (legacy section, now part of day-to-day)

## Compliance

- **TCPA hours:** call between 8 AM and 9 PM in the *recipient's* time zone.
- **National DNC list:** scrub before uploading the list, every month.
- **Internal DNC:** if someone says "remove me," tag the lead `❌ Wrong Number` or `👎 Not Interested` and never call again.
- **STIR/SHAKEN:** Twilio handles attestation automatically.
- **Spam labels:** new numbers occasionally get flagged. Register at <https://www.freecallerregistry.com/> and rotate.

---

## Troubleshooting

**"Network error reaching backend"** — Function URL is wrong, or you haven't deployed yet. In a browser, visit `https://YOURSITE.netlify.app/api?action=ping` — should return `{"error":"Unauthorized"}`. If you get a 404, the function didn't deploy.

**"Wrong password"** — `ACCESS_PASSWORD` in Netlify env doesn't match what you typed. Did you redeploy after setting env vars?

**"Server misconfigured: ACCESS_PASSWORD not set"** — env var missing. Check Netlify → Site configuration → Environment variables.

**Properties not loading** — Backend can reach Supabase but tables don't exist or RLS blocks. Verify `supabase-schema.sql` ran cleanly in the SQL Editor.

**Twilio "permission denied" when calling** — Trial accounts can only call verified numbers. Upgrade to a paid account ($20 min).

**Buy fails with "21452" or "21452: cannot purchase"** — That area code is sold out or restricted. Try a neighboring one.

**Call placed but caller ID shows "Spam Risk"** — Brand-new number. Place a few short legitimate calls to warm it up, register at Free Caller Registry, and avoid >50 calls/day on a fresh number.

---

## File map

```
.
├── index.html                     ← the entire frontend
├── netlify.toml                   ← Netlify config (function path, /api alias)
├── netlify/functions/api.js       ← the entire backend
├── supabase-schema.sql            ← run once in Supabase SQL Editor
├── sample-list.csv                ← example CSV format
└── README.md                      ← you are here
```

Five files. That's the whole app.
