-- ════════════════════════════════════════════════════════════════
-- v5 additions: Deal Qualifier Form, Owner Last Name, VA Notes
-- Run AFTER the previous schemas. Safe to re-run.
-- ════════════════════════════════════════════════════════════════

-- ── Owner last name ─────────────────────────────────────────
-- New dedicated column on properties (and deals snapshot it on create)
alter table public.properties
  add column if not exists owner_last_name text default '';

alter table public.deals
  add column if not exists owner_last_name text default '';

create index if not exists properties_lastname_idx on public.properties(owner_last_name);

-- Helper: parse last name out of an "Owners" string like
--   "DAVID & AMY JENKINS" → "Jenkins"
--   "JANE DOE"             → "Doe"
--   "SMITH, JOHN"          → "Smith"
-- (Title-cased.)
create or replace function public.parse_last_name(owners text) returns text as $$
declare
  cleaned text;
  first_segment text;
  tokens text[];
  candidate text;
begin
  if owners is null or btrim(owners) = '' then return ''; end if;
  -- If "LAST, FIRST" comma format, take the first segment
  if position(',' in owners) > 0 then
    candidate := btrim(split_part(owners, ',', 1));
  else
    -- Otherwise take the first owner before "&" or "AND"
    cleaned := regexp_replace(owners, '\s+AND\s+', ' & ', 'gi');
    first_segment := btrim(split_part(cleaned, '&', 1));
    -- Last token is the last name
    tokens := regexp_split_to_array(first_segment, '\s+');
    if array_length(tokens, 1) >= 1 then
      candidate := tokens[array_length(tokens, 1)];
    else
      candidate := '';
    end if;
  end if;
  -- Title-case
  return initcap(lower(candidate));
end;
$$ language plpgsql immutable;

-- Backfill existing rows
update public.properties
  set owner_last_name = public.parse_last_name(owners)
  where (owner_last_name is null or owner_last_name = '') and owners is not null;

update public.deals
  set owner_last_name = public.parse_last_name(owners)
  where (owner_last_name is null or owner_last_name = '') and owners is not null;

-- ── VA Notes (free text) on leads ───────────────────────────
alter table public.leads
  add column if not exists va_notes text default '';

-- ── Deal Qualifier Form (standard wholesaler fields) ────────
alter table public.deals
  add column if not exists q_motivation       text default '',  -- why are they selling
  add column if not exists q_timeline         text default '',  -- when do they need to close
  add column if not exists q_condition        text default '',  -- 1-5 or free text
  add column if not exists q_asking_price     numeric(12,2),
  add column if not exists q_mortgage_balance numeric(12,2),
  add column if not exists q_monthly_payment  numeric(12,2),
  add column if not exists q_repairs_needed   text default '',  -- list/notes
  add column if not exists q_occupancy        text default '',  -- owner | tenant | vacant
  add column if not exists q_listed_with_agent boolean,
  add column if not exists q_decision_makers  text default '',  -- who else needs to sign off
  add column if not exists q_liens_or_back_taxes text default '',
  add column if not exists q_reason_to_choose_us text default '',  -- why us, not retail
  add column if not exists q_other_offers     text default '',     -- competing offers
  add column if not exists q_extra_notes      text default '',     -- catch-all
  add column if not exists q_completed_at     timestamptz,         -- when form was filled
  add column if not exists q_completed_by_profile integer references public.profiles(id) on delete set null;
