-- ════════════════════════════════════════════════════════════════
-- Real Estate Dialer — Supabase schema
-- Paste this whole file into Supabase → SQL Editor → Run.
-- Safe to re-run: uses IF NOT EXISTS / IF EXISTS where possible.
-- ════════════════════════════════════════════════════════════════

-- Properties (uploaded via CSV)
create table if not exists public.properties (
  id              text primary key,
  owners          text not null default '',
  property_address text not null default '',
  mailing_address text not null default '',
  custom_fields   jsonb not null default '{}'::jsonb,
  imported_at     timestamptz not null default now()
);
create index if not exists properties_imported_idx on public.properties(imported_at);

create table if not exists public.phones (
  id          serial primary key,
  property_id text not null references public.properties(id) on delete cascade,
  e164        text not null,
  display     text not null,
  type        text not null default ''
);
create index if not exists phones_property_idx on public.phones(property_id);

-- Lead state per property — shared across the team
create table if not exists public.leads (
  property_id text primary key references public.properties(id) on delete cascade,
  called      boolean not null default false,
  lead_status text not null default '',
  notes       text not null default '',
  updated_at  timestamptz not null default now()
);

-- Outbound calls (from Twilio) — for KPI dashboard
create table if not exists public.calls (
  id          bigserial primary key,
  twilio_sid  text unique not null,
  property_id text references public.properties(id) on delete set null,
  from_number text,
  to_number   text,
  status      text,
  duration    integer not null default 0,
  started_at  timestamptz not null default now(),
  ended_at    timestamptz
);
create index if not exists calls_started_idx on public.calls(started_at desc);

-- ════════════════════════════════════════════════════════════════
-- Lock everything down. The Netlify Function uses the SERVICE_ROLE
-- key to bypass RLS; nobody else should touch this DB directly.
-- ════════════════════════════════════════════════════════════════

alter table public.properties enable row level security;
alter table public.phones     enable row level security;
alter table public.leads      enable row level security;
alter table public.calls      enable row level security;

-- No policies = no public access. Service role bypasses RLS by design.
