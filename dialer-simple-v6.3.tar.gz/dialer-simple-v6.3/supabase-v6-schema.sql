-- ════════════════════════════════════════════════════════════════
-- v6 additions: Cash Buyers + VA Recordings (Phase 2)
-- Run AFTER all previous schemas. Safe to re-run.
-- ════════════════════════════════════════════════════════════════

-- ── Cash Buyers ─────────────────────────────────────────────
create table if not exists public.buyers (
  id           serial primary key,
  name         text not null,
  company      text default '',
  email        text default '',
  phone        text default '',           -- E.164 if available
  city         text default '',
  state        text default '',
  zip          text default '',

  -- Criteria (what they're looking for)
  buy_box      text default '',           -- free-text: "SFR 3/2, 1200-2000 sqft, ARV $200-400k"
  min_price    numeric(12,2),
  max_price    numeric(12,2),
  property_types text default '',         -- "SFR, Duplex, Townhome"
  rehab_level  text default '',           -- 'Light' | 'Medium' | 'Heavy' | 'Any'
  cash_only    boolean default true,
  funding_proof_on_file boolean default false,
  preferred_areas text default '',        -- zip codes / neighborhoods

  notes        text default '',
  active       boolean default true,
  rating       integer default 0,         -- 0-5 stars (your subjective grade)

  -- Stats (auto-maintained)
  deals_sent   integer default 0,
  deals_closed integer default 0,
  last_sent_at timestamptz,

  created_by_profile integer references public.profiles(id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists buyers_active_idx on public.buyers(active);
create index if not exists buyers_rating_idx on public.buyers(rating desc);

-- Log of sent deals (so we don't double-send and can see history)
create table if not exists public.buyer_sends (
  id          bigserial primary key,
  buyer_id    integer not null references public.buyers(id) on delete cascade,
  deal_id     integer references public.deals(id) on delete set null,
  channel     text not null default 'email',  -- 'email' | 'sms' (future)
  subject     text default '',
  body        text default '',
  status      text not null default 'sent',   -- 'sent' | 'failed'
  error_msg   text default '',
  sent_by_profile integer references public.profiles(id) on delete set null,
  created_at  timestamptz not null default now()
);
create index if not exists buyer_sends_buyer_idx on public.buyer_sends(buyer_id, created_at desc);
create index if not exists buyer_sends_deal_idx  on public.buyer_sends(deal_id, created_at desc);

-- Touch trigger for buyers
create or replace function public.buyers_touch() returns trigger as $$
begin new.updated_at = now(); return new; end;
$$ language plpgsql;

drop trigger if exists buyers_touch on public.buyers;
create trigger buyers_touch before update on public.buyers
  for each row execute procedure public.buyers_touch();

-- ── VA Recordings (audio) ───────────────────────────────────
-- Stores metadata. The actual audio file lives in Supabase
-- Storage under bucket "va-recordings" at path "{property_id}/{id}.{ext}"
create table if not exists public.va_recordings (
  id           bigserial primary key,
  property_id  text not null references public.properties(id) on delete cascade,
  storage_path text not null,                 -- e.g. "abc123/12345.m4a"
  filename     text not null default '',
  mime_type    text default '',
  size_bytes   bigint default 0,
  duration_sec integer,
  uploaded_by_profile integer references public.profiles(id) on delete set null,
  uploaded_at  timestamptz not null default now(),
  expires_at   timestamptz not null default (now() + interval '30 days'),
  deleted_at   timestamptz                    -- NULL = still active; set when cleanup runs
);
create index if not exists varec_property_idx on public.va_recordings(property_id, uploaded_at desc);
create index if not exists varec_expires_idx  on public.va_recordings(expires_at) where deleted_at is null;

-- ── RLS ─────────────────────────────────────────────────────
alter table public.buyers         enable row level security;
alter table public.buyer_sends    enable row level security;
alter table public.va_recordings  enable row level security;

-- ── Storage bucket setup (run separately in SQL Editor) ─────
-- Supabase Storage bucket creation must be done via dashboard or
-- this SQL. Bucket is PRIVATE by default — we serve files via
-- signed URLs from the backend, never public links.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  values ('va-recordings', 'va-recordings', false, 26214400, array['audio/mpeg','audio/mp4','audio/m4a','audio/x-m4a','audio/wav','audio/webm','audio/ogg','audio/aac'])
  on conflict (id) do update set
    public = false,
    file_size_limit = 26214400,
    allowed_mime_types = array['audio/mpeg','audio/mp4','audio/m4a','audio/x-m4a','audio/wav','audio/webm','audio/ogg','audio/aac'];
-- Note: 26214400 bytes = 25 MB upload cap per file.
