-- ════════════════════════════════════════════════════════════════
-- SMS / Drip Campaign additions to the dialer CRM
-- Run AFTER supabase-schema.sql and supabase-crm-schema.sql.
-- Safe to re-run.
-- ════════════════════════════════════════════════════════════════

-- ── Consent tracking on leads ────────────────────────────────
-- We add columns to existing tables. The "preferred cell" is the
-- specific phone number from the lead's phones[] that they consented
-- to be texted on.
alter table public.leads
  add column if not exists sms_consent       text not null default 'none',  -- 'none' | 'verbal' | 'written' | 'revoked'
  add column if not exists sms_consent_at    timestamptz,
  add column if not exists sms_consent_by    text default '',                -- caller name or note
  add column if not exists sms_cell          text default '';                -- E.164 cell they consented to

create index if not exists leads_sms_consent_idx on public.leads(sms_consent);

-- ── Two-way message log ──────────────────────────────────────
-- Every text in or out lives here. Drip messages + manual messages.
create table if not exists public.messages (
  id            bigserial primary key,
  twilio_sid    text unique,                          -- nullable for queued/draft
  deal_id       integer references public.deals(id) on delete set null,
  property_id   text references public.properties(id) on delete set null,
  to_number     text not null,                        -- E.164
  from_number   text not null,                        -- E.164 (your Twilio number)
  direction     text not null,                        -- 'outbound' | 'inbound'
  body          text not null,
  status        text not null default 'queued',       -- queued|sending|sent|delivered|failed|received
  error_message text,
  campaign_id   integer,                              -- nullable; ties to drip_campaigns.id
  step_index    integer,                              -- which step in the drip
  scheduled_for timestamptz,                          -- when this should send (if queued)
  sent_at       timestamptz,
  created_at    timestamptz not null default now()
);
create index if not exists messages_deal_idx        on public.messages(deal_id, created_at desc);
create index if not exists messages_property_idx    on public.messages(property_id, created_at desc);
create index if not exists messages_to_idx          on public.messages(to_number, created_at desc);
create index if not exists messages_scheduled_idx   on public.messages(scheduled_for) where status = 'queued';
create index if not exists messages_inbound_unread_idx on public.messages(created_at desc) where direction = 'inbound';

-- ── Drip campaign instances ─────────────────────────────────
-- One row per (deal × campaign_kind) — represents "this lead is
-- in this drip series."
create table if not exists public.drip_campaigns (
  id            serial primary key,
  deal_id       integer not null references public.deals(id) on delete cascade,
  kind          text not null,                        -- 'reconsider' | 'comp' | 'three_month' | 'six_month'
  status        text not null default 'pending_approval', -- pending_approval|active|paused|completed|opted_out
  trigger_date  timestamptz not null,                 -- when this drip's day-0 begins
  started_at    timestamptz,
  paused_reason text default '',                      -- 'inbound_reply' | 'manual' | 'opted_out'
  created_at    timestamptz not null default now(),
  unique(deal_id, kind)                                -- one of each kind per deal
);
create index if not exists drip_deal_idx     on public.drip_campaigns(deal_id);
create index if not exists drip_status_idx   on public.drip_campaigns(status);

-- ── Per-number opt-out list (the iron-clad block list) ──────
-- Once a number replies STOP we never text it again, even
-- through a different deal/property.
create table if not exists public.sms_opt_outs (
  e164          text primary key,
  opted_out_at  timestamptz not null default now(),
  reason        text default 'stop_keyword'           -- 'stop_keyword' | 'manual' | 'complaint'
);

-- ── Twilio number used for SMS sending ──────────────────────
-- We're letting the admin pick which owned number is the "SMS sender"
-- (often different from the dialer caller-ID rotation). Lives in
-- user_prefs-style row but app-wide (single-tenant app).
create table if not exists public.app_config (
  key   text primary key,
  value text not null default ''
);
-- Pre-seed the keys we use
insert into public.app_config (key, value) values ('sms_from_number', '') on conflict (key) do nothing;
insert into public.app_config (key, value) values ('sms_business_name', '') on conflict (key) do nothing;

-- ── RLS ──────────────────────────────────────────────────────
alter table public.messages         enable row level security;
alter table public.drip_campaigns   enable row level security;
alter table public.sms_opt_outs     enable row level security;
alter table public.app_config       enable row level security;
-- service role bypasses RLS; no public policies needed.
